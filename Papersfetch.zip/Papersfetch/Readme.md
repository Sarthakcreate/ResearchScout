# get-papers-list

A CLI tool to fetch PubMed papers where at least one author is affiliated with a pharmaceutical or biotech company.

## 📦 Features

- Query PubMed using the official API
- Detect non-academic authors based on heuristics (emails, affiliations)
- Output CSVs with paper details
- CLI options for debug, file output, and help

## 🚀 Installation

```power_shell
poetry install
poetry run get-papers-list "cancer immunotherapy" --file results.csv --debug

